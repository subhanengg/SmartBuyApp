package smartbuy.handlers;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import smartbuy.beans.DatabaseConnection;
import smartbuy.beans.PostAdRequest;
import smartbuy.beans.PostAdResponse;

public class PostAdHandler {

	public PostAdResponse postAd(PostAdRequest postAdRequest) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement statement = null;
		DatabaseConnection databaseConnection = null;
		PostAdResponse postAdResponse = new PostAdResponse();
		try {
			databaseConnection = new DatabaseConnection();
			conn = databaseConnection.openDB();
			statement = conn.createStatement();
			String sqlPostAd = "INSERT INTO addetails(adtitle, userid, addesc, category, city, image, status, posteddate, posttype) VALUES ('"
					+ postAdRequest.getAdTitle()
					+ "',"
					+ "'"
					+ postAdRequest.getUserId()
					+ "',"
					+ "'"
					+ postAdRequest.getDescription()
					+ "',"
					+ "'"
					+ postAdRequest.getCategory()
					+ "',"
					+ "'"
					+ postAdRequest.getLocation()
					+ "',"
					+ "'"
					+ postAdRequest.getImage()
					+ "',"
					+ "'"
					+ "A"
					+ "',"
					+ ""
					+ "CURRENT_TIMESTAMP"
					+ ","
					+ "'"
					+ postAdRequest.getPostType()
					+ "'"					
					+ ")";
			
			int result = statement.executeUpdate(sqlPostAd);
			if(result != 0){
				postAdResponse.setMessage("Ad posted successfully!");
			}
			else {
				postAdResponse.setMessage("Error in posting Ad");
			}
		}

		catch (Exception e) {
			System.out.println("Error in the database");
			postAdResponse.setMessage("Error in the database connection");
		} finally {
			// Close the database connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return postAdResponse;
	}
	
	
	
}
