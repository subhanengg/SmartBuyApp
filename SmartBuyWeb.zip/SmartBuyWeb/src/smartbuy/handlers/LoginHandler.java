package smartbuy.handlers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import smartbuy.beans.DatabaseConnection;
import smartbuy.beans.UserBean;

public class LoginHandler {
	Connection conn=null;
	Statement statement=null;	
	DatabaseConnection databaseConnection = null;
	
	// To validate the userId and password	
	public UserBean validateUser(String userId,String password)
		{
			UserBean userTo = null;
			databaseConnection = new DatabaseConnection();
			try{
				conn = databaseConnection.openDB();
				Statement statement = conn.createStatement();		
				ResultSet resultSet = statement.executeQuery("SELECT * FROM login WHERE userId = '"+userId+"' and password = '"+password+"'" );			
				if(resultSet.next()){
					userTo = new UserBean();
					userTo.setUserId(resultSet.getString(1));
					userTo.setPassword(resultSet.getString(2));
					userTo.setMessage("Valid");
					
				}
				else
				{ 
					userTo = new UserBean();
					System.out.println("User name & password incorrect ::: "+userId+":::"+password);
					userTo.setMessage("User name & password incorrect");
							
				}
				return userTo;
			}
			
			catch(Exception e){
				System.out.println("Error in the database");
				userTo = new UserBean();
				userTo.setMessage("Error in the database connection");
				
			}	
			finally{
				//Close the database connection
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return userTo;
		}
		
	
}
