package smartbuy.handlers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import smartbuy.beans.Ad;
import smartbuy.beans.DatabaseConnection;
import smartbuy.beans.MyAdsResponse;

public class BrowseAdsHandler {

	Connection conn = null;
	Statement statement = null;
	DatabaseConnection databaseConnection = null;

	// List of all ads will fetched specific to user bu its userId
	public MyAdsResponse browseAds() {
		MyAdsResponse myAdsResponse = new MyAdsResponse();		
		databaseConnection = new DatabaseConnection();
		try {
			conn = databaseConnection.openDB();
			Statement statement = conn.createStatement();
			Statement statement2 = conn.createStatement();
			ResultSet resultSet = statement
					.executeQuery("select * from addetails WHERE status = 'A' ORDER BY posteddate DESC" );
			List<Ad> myAds = new ArrayList<Ad>();
			int flag = 0;
//			 `adid`, `adtitle`, `userid`, `addesc`, `category`, 
//			 `city`, `image`, `status`, `posteddate`, `posttype` 
			while (resultSet.next()) {				
				Ad ad = new Ad();
				ad.setAdId(resultSet.getString("adid"));
				ad.setAdTitle(resultSet.getString("adtitle"));
				ad.setUserId(resultSet.getString("userid"));
				ad.setDescription(resultSet.getString("addesc"));
				ad.setCategory(resultSet.getString("category"));
				ad.setCity(resultSet.getString("city"));
				ad.setImage(resultSet.getString("image"));				
				ad.setPostedDate(resultSet.getString("posteddate"));
				ad.setPostType(resultSet.getString("posttype"));
				ResultSet resultSetUser = statement2
						.executeQuery("select * from userdetails WHERE userId = '" + ad.getUserId() +"'" );
				if(resultSetUser.next()){
					ad.setPostedBy(resultSetUser.getString("name"));
					ad.setPhone(resultSetUser.getString("phone"));
					ad.setEmail(resultSetUser.getString("email"));
				}
				myAds.add(ad);	
				flag = 1;
			}
			
			if(flag == 1){
				myAdsResponse.setMessage("List of Ads!");
				myAdsResponse.setMyAds(myAds);
			}else {
				myAdsResponse.setMessage("No Ads exists!");
				myAdsResponse.setMyAds(null);
			}
			
			return myAdsResponse;
		}

		catch (Exception e) {
			System.out.println("Error in the database");
			myAdsResponse.setMessage("Error in the database connection");

		} finally {
			// Close the database connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return myAdsResponse;
	}


	
}
