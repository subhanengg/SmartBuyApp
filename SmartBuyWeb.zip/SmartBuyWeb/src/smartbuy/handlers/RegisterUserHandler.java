package smartbuy.handlers;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import smartbuy.beans.DatabaseConnection;
import smartbuy.beans.RegisterUserRequest;
import smartbuy.beans.RegisterUserResponse;
import smartbuy.beans.UserBean;

public class RegisterUserHandler {

	// To register user and details in database
	public RegisterUserResponse registerUser(RegisterUserRequest userRequest) {
		Connection conn = null;
		Statement statement = null;
		DatabaseConnection databaseConnection = null;
		RegisterUserResponse userResponse = new RegisterUserResponse();
		try {
			databaseConnection = new DatabaseConnection();
			conn = databaseConnection.openDB();
			statement = conn.createStatement();
			String sqlDetails = "INSERT INTO userdetails(userid, name, phone, email) VALUES ('"
					+ userRequest.getUserId()
					+ "',"
					+ "'"
					+ userRequest.getName()
					+ "',"
					+ "'"
					+ userRequest.getMobile()
					+ "',"
					+ "'"
					+ userRequest.getEmail() + "'" + ")";
			String sqlLogin = "INSERT INTO login(userid, password) VALUES ('"
					+ userRequest.getUserId() + "'," + "'"
					+ userRequest.getPassword() + "'" + ")";
			LoginHandler loginHandler = new LoginHandler();
			UserBean userBean = new UserBean();
			userBean = loginHandler.validateUser(userRequest.getUserId(),
					userRequest.getPassword());
			if (userBean.getUserId() == null && !(userBean.getMessage().contains("Valid"))) {
				int result = statement.executeUpdate(sqlLogin);
				if (result != 0) {
					result = statement.executeUpdate(sqlDetails);
					if (result != 0) {
						userResponse.setMessage("Registered succesfully!");
						// Fetch the list of ads of user here
					}
				}
			}
			else {
				System.out.println("User already exist ::: ");
				userResponse.setMessage("User already exist");
			}
		}

		catch (Exception e) {
			System.out.println("Error in the database");
			userResponse.setMessage("Error in the database connection");
		} finally {
			// Close the database connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userResponse;
	}

}
