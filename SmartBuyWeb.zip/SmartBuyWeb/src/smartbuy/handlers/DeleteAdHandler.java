package smartbuy.handlers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import smartbuy.beans.DatabaseConnection;
import smartbuy.beans.DeleteAdResponse;

public class DeleteAdHandler {

	Connection conn = null;
	Statement statement = null;
	DatabaseConnection databaseConnection = null;

	// Mark the ad as deleted in database
	public DeleteAdResponse deleteAd(int adId) {
		DeleteAdResponse deleteAdResponse = new DeleteAdResponse();		
		databaseConnection = new DatabaseConnection();
		try {
			conn = databaseConnection.openDB();
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement
					.executeQuery("select * from addetails WHERE status = 'A' and adid = "
							+ adId);
			if (resultSet.next()) {
				int result = statement
						.executeUpdate("UPDATE addetails SET status='D' WHERE adid = "
								+ adId);
				if (result != 0) {
					deleteAdResponse.setMessage("Ad Deleted Successfully!");
					deleteAdResponse.setDeleted(true);
				} else {
					deleteAdResponse
							.setMessage("Failed to delete Ad! Try again");
					deleteAdResponse.setDeleted(false);
				}
			}
			else {
				deleteAdResponse
						.setMessage("This Ad doesn't exists!");
				deleteAdResponse.setDeleted(false);
			}
			
			return deleteAdResponse;
		}

		catch (Exception e) {
			System.out.println("Error in the database");
			deleteAdResponse.setMessage("Error in the database connection");

		} finally {
			// Close the database connection
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return deleteAdResponse;
	}

}
