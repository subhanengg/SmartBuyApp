package smartbuy.webservices;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import smartbuy.beans.DeleteAdResponse;
import smartbuy.beans.MyAdsResponse;
import smartbuy.beans.PostAdRequest;
import smartbuy.beans.PostAdResponse;
import smartbuy.beans.RegisterUserRequest;
import smartbuy.beans.RegisterUserResponse;
import smartbuy.beans.UserBean;
import smartbuy.handlers.BrowseAdsHandler;
import smartbuy.handlers.DeleteAdHandler;
import smartbuy.handlers.LoginHandler;
import smartbuy.handlers.MyAdsHandler;
import smartbuy.handlers.PostAdHandler;
import smartbuy.handlers.RegisterUserHandler;

@Path("/smartBuy")
public class SmartBuy {

	@Path("/login/{userId}/{password}")
	@GET
	@Produces("application/json")
	public UserBean validateUser(@PathParam("userId") String userId, 
			@PathParam("password") String password){
		System.out.println("::Validate User::");
		UserBean userResult = null;
		LoginHandler loginHandler = new LoginHandler();
		userResult = loginHandler.validateUser(userId, password);		
		System.out.println("::Validate User::");
		return userResult;
	}
	
	@Path("/register/{userId}/{password}/{name}/{mobile}/{email}")
	@GET
	@Produces("application/json")
	public RegisterUserResponse registerUser(@PathParam("userId") String userId, 
			@PathParam("password") String password,
			@PathParam("name") String name,
			@PathParam("mobile") String mobile, 
			@PathParam("email") String email){
		System.out.println("::Register User::");
		RegisterUserResponse registerUserResponse = new RegisterUserResponse();
		RegisterUserRequest registerUserRequest = new RegisterUserRequest(userId, name, password, email, mobile);
		registerUserResponse = new RegisterUserHandler().registerUser(registerUserRequest);
				
		System.out.println("::Register User::");
		return registerUserResponse;
	}
	
//	@Provider
//	@Consumes("image/jpeg")
//	class ImageProvider implements MessageBodyReader<Image> {
//
//	    public Image readFrom(Class<Image> type,
//	                                Type genericType,
//	                                Annotation[] annotations,
//	                                MediaType mediaType,
//	                                MultivaluedMap<String, String> httpHeaders,
//	                                InputStream entityStream) throws IOException,
//	        WebApplicationException {
//	       // create Image from stream
//	    }
//	}
	
	
	@Path("/postAd/{userId}/{postType}/{category}/{title}/{description}/{price}/{image}/{location}")
	@GET
	@Produces("application/json")
	public PostAdResponse postAd(
			@PathParam("userId") String userId, 
			@PathParam("postType") String postType,
			@PathParam("category") String category,
			@PathParam("title") String title,
			@PathParam("description") String description, 
			@PathParam("price") String price, 
			@PathParam("image") String image, 
			@PathParam("location") String location){
		System.out.println("::Post an Ad::");
		PostAdResponse postAdResponse = new PostAdResponse();
		PostAdRequest postAdRequest = new PostAdRequest();
		postAdRequest.setUserId(userId);
		postAdRequest.setAdTitle(title);
		postAdRequest.setPostType(postType);
		postAdRequest.setCategory(category);
		postAdRequest.setDescription(description);
		postAdRequest.setPrice(price);
		postAdRequest.setImage(image);
		postAdRequest.setLocation(location);
		
		PostAdHandler postAdHandler = new PostAdHandler();
		postAdResponse = postAdHandler.postAd(postAdRequest);
		
		System.out.println("::Post an Ad::");
		return postAdResponse;
	}
	
	@Path("/deleteAd/{adId}")
	@GET
	@Produces("application/json")
	public DeleteAdResponse deleteAd(
			@PathParam("adId") String adId){
		System.out.println("::Delete an Ad::");
		
		DeleteAdResponse deleteAdResponse = new DeleteAdResponse();
		DeleteAdHandler deleteAdHandler = new DeleteAdHandler();
		deleteAdResponse = deleteAdHandler.deleteAd(Integer.parseInt(adId));
		
		System.out.println("::Delete an Ad::");
		return deleteAdResponse;
	}
	
	@Path("/myAds/{userId}")
	@GET
	@Produces("application/json")
	public MyAdsResponse myAds(
			@PathParam("userId") String userId){
		System.out.println("::My Ads::");
		MyAdsResponse myAdsResponse = new MyAdsResponse();
		MyAdsHandler myAdsHandler = new MyAdsHandler();
		myAdsResponse = myAdsHandler.myAds(userId);
		System.out.println("::My Ads::");
		return myAdsResponse;
	}
	
	
	@Path("/browseAds/")
	@GET
	@Produces("application/json")
	public MyAdsResponse browseAds(){
		System.out.println("::Browse Ads::");
		MyAdsResponse browseAdsResponse = new MyAdsResponse();
		BrowseAdsHandler browseAdsHandler = new BrowseAdsHandler();
		browseAdsResponse = browseAdsHandler.browseAds();
		System.out.println("::Browse Ads::");
		return browseAdsResponse;
	}
}
