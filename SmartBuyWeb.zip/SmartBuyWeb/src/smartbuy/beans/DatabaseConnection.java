package smartbuy.beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseConnection {

	private static Connection conn = null;
	private static Statement statement = null;
	private static String url = "jdbc:mysql://localhost:3306/rentdatabase";
	private static String username = "root";
	private static String password = "";

	public DatabaseConnection() {
		// TODO Auto-generated constructor stub
		
	}
	
	public Connection openDB() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);
			//statement = conn.createStatement();
			return conn;
		} catch (Exception e) {
			System.out.println("Excep in Open Database connectivity"+e);
		}
		return null;
	}
	
	public void closeDB() {
		// TODO Auto-generated method stub
		try {
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Excep in Close Database connectivity"+e);
		}
	}
}
