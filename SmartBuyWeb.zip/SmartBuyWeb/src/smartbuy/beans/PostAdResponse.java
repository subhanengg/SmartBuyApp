package smartbuy.beans;

public class PostAdResponse {
	private String message;
	private String AdId;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAdId() {
		return AdId;
	}
	public void setAdId(String adId) {
		AdId = adId;
	}
	
}
