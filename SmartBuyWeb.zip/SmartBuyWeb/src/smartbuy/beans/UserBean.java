package smartbuy.beans;

public class UserBean {
	private String userId;
	private String password;
	private String message;
	
	
	public UserBean(){
		
	}
	public UserBean(String userId, String password)
	{
		this.userId = userId;
		this.password = password;
	}
	
	// set the userId
	public void setUserId(String userId) 
	{
		this.userId = userId;
	}
	
	// get the userId
	public String getUserId() 
	{
		return userId;
	}
	
	//set the password
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	//get the password
	public String getPassword()
	{
		return password;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
