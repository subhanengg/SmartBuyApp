package smartbuy.beans;

public class UserDetails {

	private String userId;
	private String name;

	private String mobile;
	private String email;
	private String password ; 
	
	public UserDetails() {
		// TODO Auto-generated constructor stub
	}
	public UserDetails(String userId, String name, String password, String email, String mobile) {
		// TODO Auto-generated method stub
		this.userId = userId;
		this.email = email;
		this.password = password;
		this.name = name;
		this.mobile = mobile;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
}
