package smartbuy.beans;

import java.util.List;

public class MyAdsResponse {
	
	private String message;
	private List<Ad> myAds;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Ad> getMyAds() {
		return myAds;
	}
	public void setMyAds(List<Ad> myAds) {
		this.myAds = myAds;
	}	
}
