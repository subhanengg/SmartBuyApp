package smartbuy.beans;

public class PostAdRequest {
	private String postType;
	private String adTitle;
	private String userId;
	private String description;
	private String category;
	private String location;
	private String postedDate;
	private String price;
	private String image;
	private String adFlag;
	
	public PostAdRequest() {
		// TODO Auto-generated constructor stub
	}
	
	public String getPostType() {
		return postType;
	}
	
	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public void setPostType(String postType) {
		this.postType = postType;
	}
	public String getAdTitle() {
		return adTitle;
	}
	public void setAdTitle(String adTitle) {
		this.adTitle = adTitle;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPostedDate() {
		return postedDate;
	}
	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getAdFlag() {
		return adFlag;
	}
	public void setAdFlag(String adFlag) {
		this.adFlag = adFlag;
	}
}
